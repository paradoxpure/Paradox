// Example JS code
document.addEventListener("DOMContentLoaded", function() {
  // Add your JavaScript code here
});